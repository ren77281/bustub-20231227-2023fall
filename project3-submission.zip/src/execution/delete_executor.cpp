//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// delete_executor.cpp
//
// Identification: src/execution/delete_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <cstdint>
#include <memory>

#include "execution/executors/delete_executor.h"
#include "storage/table/tuple.h"

namespace bustub {

DeleteExecutor::DeleteExecutor(ExecutorContext *exec_ctx, const DeletePlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx),
      plan_(plan),
      child_executor_(std::move(child_executor)) {}

void DeleteExecutor::Init() { this->child_executor_->Init(); }

auto DeleteExecutor::Next([[maybe_unused]] Tuple *tuple, RID *rid) -> bool {
  if (this->is_executed) {
    return false;
  }
  int32_t cnt = 0;
  Tuple children_tuple{};
  while (this->child_executor_->Next(&children_tuple, rid)) {
    TableInfo *table_info = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->GetTableOid());
    TupleMeta meta = table_info->table_->GetTupleMeta(*rid);
    meta.is_deleted_ = true;
    table_info->table_->UpdateTupleMeta(meta, *rid);
    /** 索引的删除 */
    std::vector<IndexInfo *> indexes = this->GetExecutorContext()->GetCatalog()->GetTableIndexes(table_info->name_);
    for (const auto &index_info : indexes) {
      index_info->index_->DeleteEntry(children_tuple.KeyFromTuple(table_info->schema_, index_info->key_schema_,
                            index_info->index_->GetKeyAttrs()), *rid, nullptr);
    }
    cnt++;
  }
  std::vector<Value> value_cnt;
  value_cnt.push_back(Value{TypeId::INTEGER, cnt});
  *tuple = Tuple{value_cnt, &this->GetOutputSchema()};
  this->is_executed = true;
  return true;
}

}  // namespace bustub
