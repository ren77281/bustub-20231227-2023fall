//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// seq_scan_executor.cpp
//
// Identification: src/execution/seq_scan_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/seq_scan_executor.h"
#include "execution/expressions/column_value_expression.h"
#include "execution/expressions/comparison_expression.h"
#include "storage/table/table_heap.h"
#include "execution/expressions/constant_value_expression.h"
#include "type/type_id.h"

namespace bustub {

SeqScanExecutor::SeqScanExecutor(ExecutorContext *exec_ctx, const SeqScanPlanNode *plan)
    : AbstractExecutor(exec_ctx),
      plan_(plan),
      it_(this->GetExecutorContext()->GetCatalog()->GetTable(plan->GetTableOid())->table_->MakeIterator()),
      back_it_(tuples_.begin()) {}

void SeqScanExecutor::Init() {
  // std::cout << "init~~~~\n";
  this->back_it_ = this->tuples_.begin();
}

auto SeqScanExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  // std::cout << "调用!!!!!!!!!!!\n";
  /** 非第一次调用，如果back_it指向end，则返回 */
  if (!this->is_first_ && this->back_it_ == this->tuples_.end()) {
    // std::cout << "非第一次调用结束\n";
    return false;
  }
  /** 非第一次调用，返回已经保存的结果即可 */
  if (!this->is_first_) {
    *tuple = *this->back_it_;
    ++this->back_it_;
    // std::cout << "非第一次调用\n";
    return true;
  }
  if (this->it_.IsEnd()) {
    this->is_first_ = false;
    return false;
  }
  /** 直到返回未被删除的tuple或者没有tuple停止 */
  while (!this->it_.IsEnd()) {
    std::pair<TupleMeta, Tuple> res = this->it_.GetTuple();
    /** 被删除的tuple */
    if (res.first.is_deleted_) {
      ++this->it_;
      continue;
    }
    /** 没有被删除，且没有filter条件 */
    if (this->plan_->filter_predicate_ == nullptr) {
      *tuple = res.second;
      *rid = this->it_.GetRID();
      if (is_first_) {
        this->tuples_.push_back(*tuple);
        this->back_it_ = this->tuples_.begin();
      }
      ++this->it_;
      // std::cout << "第一次调用\n";
      return true;
    }
    /** 判断是否满足filter条件 */
    Value is_equal = this->plan_->filter_predicate_->Evaluate(&res.second, this->plan_->OutputSchema());
    /** 满足filter条件 */
    if (!is_equal.IsNull() && is_equal.GetAs<bool>()) {
      *tuple = res.second;
      *rid = this->it_.GetRID();
      if (is_first_) {
        this->tuples_.push_back(*tuple);
        this->back_it_ = this->tuples_.begin();
      }
      ++this->it_;
      // std::cout << "第一次调用\n";
      return true;
    }
    /** 不满足filter条件 */
    ++this->it_;
  }
  // std::cout << "last:right结束\n";
  this->is_first_ = false;
  return false;
}

}  // namespace bustub
