//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// update_executor.cpp
//
// Identification: src/execution/update_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//
#include <memory>

#include "catalog/catalog.h"
#include "execution/executors/update_executor.h"

namespace bustub {

UpdateExecutor::UpdateExecutor(ExecutorContext *exec_ctx, const UpdatePlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

void UpdateExecutor::Init() { this->child_executor_->Init(); }

auto UpdateExecutor::Next([[maybe_unused]] Tuple *tuple, RID *rid) -> bool {
  if (this->is_executed_) {
    return false;
  }
  int32_t cnt = 0;
  Tuple children_tuple{};
  /** TODO:似乎有些冗余 */
  while (child_executor_->Next(&children_tuple, rid)) {
    /** 先删除 */
    TableInfo *table_info = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->GetTableOid());
    /** 获取旧tuple */
    std::pair<TupleMeta, Tuple> old_tuple_pair = table_info->table_->GetTuple(*rid);
    auto meta = old_tuple_pair.first;
    meta.is_deleted_ = true;
    table_info->table_->UpdateTupleMeta(meta, *rid);
    std::vector<IndexInfo *> indexes = this->GetExecutorContext()->GetCatalog()->GetTableIndexes(table_info->name_);
    for (const auto &index_info : indexes) {
      index_info->index_->DeleteEntry(old_tuple_pair.second.KeyFromTuple(table_info->schema_, index_info->key_schema_,
                                                                         index_info->index_->GetKeyAttrs()),
                                      *rid, nullptr);
    }
    /** 再插入 */
    std::vector<Value> values;
    for (const auto &expr : this->plan_->target_expressions_) {
      values.push_back(expr->Evaluate(&old_tuple_pair.second, table_info->schema_));
    }
    Tuple new_tuple(values, &table_info->schema_);
    auto res = table_info->table_->InsertTuple(TupleMeta{}, new_tuple);
    if (res) {
      for (const auto &index_info : indexes) {
        index_info->index_->InsertEntry(
            new_tuple.KeyFromTuple(table_info->schema_, index_info->key_schema_, index_info->index_->GetKeyAttrs()),
            *res, nullptr);
      }
      cnt++;
    }
  }
  std::vector<Value> value_cnt;
  value_cnt.emplace_back(TypeId::INTEGER, cnt);
  *tuple = Tuple(value_cnt, &this->GetOutputSchema());
  this->is_executed_ = true;
  return true;
}

}  // namespace bustub
