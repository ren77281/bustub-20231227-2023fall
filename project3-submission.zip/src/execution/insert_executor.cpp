//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// insert_executor.cpp
//
// Identification: src/execution/insert_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <memory>

#include "execution/executors/insert_executor.h"

namespace bustub {

InsertExecutor::InsertExecutor(ExecutorContext *exec_ctx, const InsertPlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx),
      plan_(plan),
      child_executor_(std::move(child_executor)) {}

void InsertExecutor::Init() { this->child_executor_->Init(); }

auto InsertExecutor::Next([[maybe_unused]] Tuple *tuple, RID *rid) -> bool {
  if (this->is_executed) {
    return false;
  }
  int32_t cnt = 0;
  Tuple children_tuple{};
  while (this->child_executor_->Next(&children_tuple, rid)) {
    TableInfo *table_info = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->GetTableOid());
    auto res = table_info->table_->InsertTuple(TupleMeta{}, children_tuple);
    if (res) {
      cnt++;
      *rid = *res;
      /** 维护索引 */
      std::vector<IndexInfo *> indexes = this->GetExecutorContext()->GetCatalog()->GetTableIndexes(table_info->name_);
      for (const IndexInfo *index_info : indexes) {
        index_info->index_->InsertEntry(children_tuple.KeyFromTuple(table_info->schema_, index_info->key_schema_,
                                        index_info->index_->GetKeyAttrs()), *rid, nullptr);
      }
    }
  }
  std::vector<Value> value_cnt;
  value_cnt.push_back(Value{TypeId::INTEGER, cnt});
  *tuple = Tuple(value_cnt, &this->GetOutputSchema());
  this->is_executed = true;
  return true;
}

}  // namespace bustub
