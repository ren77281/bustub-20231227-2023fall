#include "execution/expressions/column_value_expression.h"
#include "execution/expressions/constant_value_expression.h"
#include "execution/plans/abstract_plan.h"
#include "execution/plans/index_scan_plan.h"
#include "execution/plans/seq_scan_plan.h"
#include "optimizer/optimizer.h"
#include "storage/index/index.h"

namespace bustub {

auto Optimizer::OptimizeSeqScanAsIndexScan(const bustub::AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef {
  AbstractPlanNodeRef optimized_plan = OptimizeMergeFilterScan(plan);
  if (optimized_plan->GetType() == PlanType::SeqScan) {
    auto seq_scan_plan = dynamic_cast<const SeqScanPlanNode *>(optimized_plan.get());
    if (seq_scan_plan->filter_predicate_== nullptr) {
      return optimized_plan;
    }
    auto left_const_expr = dynamic_cast<ConstantValueExpression *>(
        seq_scan_plan->filter_predicate_->GetChildAt(0).get());
    auto right_const_expr = dynamic_cast<ConstantValueExpression *>(
        seq_scan_plan->filter_predicate_->GetChildAt(1).get());
    auto left_column_expr = dynamic_cast<ColumnValueExpression *>(
        seq_scan_plan->filter_predicate_->GetChildAt(0).get());
    auto right_column_expr = dynamic_cast<ColumnValueExpression *>(
        seq_scan_plan->filter_predicate_->GetChildAt(0).get());
    auto const_expr = left_const_expr != nullptr ? left_const_expr : right_const_expr;
    auto column_expr = left_column_expr != nullptr ? left_column_expr : right_column_expr;
    if (const_expr && column_expr) {
      uint32_t col_idx = column_expr->GetColIdx();
      std::vector<IndexInfo *> indexes = this->catalog_.GetTableIndexes(seq_scan_plan->table_name_);
      for (const auto &index_info : indexes) {
        std::vector<uint32_t> key_attrs = index_info->index_->GetKeyAttrs();
        for (const auto &attr : key_attrs) {
          if (attr == col_idx) {
            auto res = std::make_shared<IndexScanPlanNode>(seq_scan_plan->output_schema_, seq_scan_plan->GetTableOid(),
                index_info->index_oid_, seq_scan_plan->filter_predicate_, const_expr);
            return res;
          }
        }
      }
    }
  }
  return optimized_plan;
}

}  // namespace bustub
