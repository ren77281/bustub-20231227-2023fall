//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// index_scan_executor.cpp
//
// Identification: src/execution/index_scan_executor.cpp
//
// Copyright (c) 2015-19, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//
#include "execution/executors/index_scan_executor.h"

namespace bustub {
IndexScanExecutor::IndexScanExecutor(ExecutorContext *exec_ctx, const IndexScanPlanNode *plan)
    : AbstractExecutor(exec_ctx), plan_(plan) {}

void IndexScanExecutor::Init() {
  IndexInfo *index_info = this->GetExecutorContext()->GetCatalog()->GetIndex(this->plan_->index_oid_);
  this->table_info_ = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->table_oid_);
  auto hash_index = dynamic_cast<HashTableIndexForTwoIntegerColumn *>(index_info->index_.get());
  Tuple key_tuple({this->plan_->pred_key_->val_}, &index_info->key_schema_);
  hash_index->ScanKey(key_tuple, &this->results_, nullptr);
}

auto IndexScanExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  /** 遍历results，检查是否被删除 */
  while (this->i_ < this->results_.size()) {
    *rid = this->results_[this->i_];
    std::pair<TupleMeta, Tuple> tuple_pair = table_info_->table_->GetTuple(*rid);
    if (!tuple_pair.first.is_deleted_) {
      *tuple = tuple_pair.second;
      this->i_++;
      return true;
    }
    this->i_++;
  }
  /** 没有tuple或者剩下的都是被删除的tuple */
  return false;
}

}  // namespace bustub
