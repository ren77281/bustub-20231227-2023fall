//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// delete_executor.cpp
//
// Identification: src/execution/delete_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <cstdint>
#include <memory>

#include "common/config.h"
#include "common/exception.h"
#include "concurrency/transaction.h"
#include "concurrency/transaction_manager.h"
#include "execution/execution_common.h"
#include "execution/executors/delete_executor.h"
#include "storage/table/tuple.h"

namespace bustub {

DeleteExecutor::DeleteExecutor(ExecutorContext *exec_ctx, const DeletePlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

void DeleteExecutor::Init() { this->child_executor_->Init(); }

auto DeleteExecutor::Next([[maybe_unused]] Tuple *tuple, RID *rid) -> bool {
  if (this->is_executed_) {
    return false;
  }
  int32_t cnt = 0;
  Tuple children_tuple{};
  TableInfo *table_info = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->GetTableOid());
  Transaction *txn = this->GetExecutorContext()->GetTransaction();
  TransactionManager *txn_mgr = this->GetExecutorContext()->GetTransactionManager();
  while (this->child_executor_->Next(&children_tuple, rid)) {
    std::optional<UndoLink> first_link = txn_mgr->GetUndoLink(*rid);
    if (!first_link.has_value()) {
      LOG_ERROR("rid的版本链存在问题");
      throw ExecutionException("rid的版本链存在问题");
    }
    auto [meta, delete_tuple] = table_info->table_->GetTuple(*rid);
    /** 如果是自我修改 */
    if (meta.ts_ == txn->GetTransactionId()) {
      if (!meta.is_deleted_) {
        meta.is_deleted_ = true;
        table_info->table_->UpdateTupleMeta(meta, *rid);
        cnt++;
      }
      continue;
    }
    cnt++;
    /** 检测写写冲突 */
    if (meta.ts_ >= TXN_START_ID || (meta.ts_ < TXN_START_ID && meta.ts_ > txn->GetReadTs())) {
      LOG_DEBUG("发生了写写冲突, %ld", meta.ts_);
      txn->SetTainted();
      throw ExecutionException("发生了写写冲突");
    }
    /** 正常写入，先构建undo log */
    UndoLog undo_log = GetDeleteUndoLog(table_info->schema_, *first_link, meta.ts_, delete_tuple);
    /** 再构建对于的undo link并维护版本链 */
    ConstructAndUpdateUndoLink(txn->GetTransactionId(), txn->GetUndoLogNum(), txn_mgr, *rid);
    /** 更新base tuple的is_delete标记 */
    meta.ts_ = txn->GetTransactionId();
    meta.is_deleted_ = true;
    table_info->table_->UpdateTupleMeta(meta, *rid);
    /** 更新事务的undo log与write set */
    txn->AppendUndoLog(undo_log);
    txn->AppendWriteSet(this->plan_->GetTableOid(), *rid);
  }
  std::vector<Value> value_cnt;
  value_cnt.emplace_back(TypeId::INTEGER, cnt);
  *tuple = Tuple{value_cnt, &this->GetOutputSchema()};
  this->is_executed_ = true;
  return true;
}

}  // namespace bustub
