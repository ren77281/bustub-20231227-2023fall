//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// delete_executor.cpp
//
// Identification: src/execution/delete_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <cstdint>
#include <memory>

#include "common/config.h"
#include "common/exception.h"
#include "concurrency/transaction.h"
#include "concurrency/transaction_manager.h"
#include "execution/execution_common.h"
#include "execution/executors/delete_executor.h"
#include "storage/table/tuple.h"

namespace bustub {

DeleteExecutor::DeleteExecutor(ExecutorContext *exec_ctx, const DeletePlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

void DeleteExecutor::Init() { this->child_executor_->Init(); }

auto DeleteExecutor::Next([[maybe_unused]] Tuple *tuple, RID *rid) -> bool {
  if (this->is_executed_) {
    return false;
  }
  int32_t cnt = 0;
  Tuple children_tuple{};
  TableInfo *table_info = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->GetTableOid());
  Transaction *txn = this->GetExecutorContext()->GetTransaction();
  TransactionManager *txn_mgr = this->GetExecutorContext()->GetTransactionManager();
  while (this->child_executor_->Next(&children_tuple, rid)) {
    RID modified_rid = *rid;
    auto [meta, delete_tuple] = table_info->table_->GetTuple(modified_rid);
    /** 保存VersionUndoLink */
    std::optional<VersionUndoLink> original_version_link = txn_mgr->GetVersionLink(modified_rid);
    if (!original_version_link.has_value()) {
      txn->SetTainted();
      throw Exception("获取VerionLink失败，存在非法rid\n");
    }
    /** 不能修改其他事务正在操作的tuple */
    if (original_version_link->in_progress_ && meta.ts_ != txn->GetTransactionId()) {
      txn->SetTainted();
      throw ExecutionException("不能修改其他事务正在操作的tuple\n");
    }
    UndoLink first_link = original_version_link->prev_;
    /** 如果是自我修改 */
    if (meta.ts_ == txn->GetTransactionId()) {
      if (!meta.is_deleted_) {
        if (first_link.IsValid()) {
          /** 先保存该undo log的下标与undo log */
          size_t undo_log_idx = first_link.prev_log_idx_;
          UndoLog old_undo_log = txn->GetUndoLog(undo_log_idx);
          /** 验证第一个undo log由当前事务创建 */
          if (txn->GetTransactionId() != first_link.prev_txn_) {
            txn->SetTainted();
            LOG_ERROR("版本链存在问题，第一个undo log不是当前事务创建，没有解决写写冲突？");
            throw ExecutionException("版本链存在问题，第一个undo log不是当前事务创建，没有解决写写冲突？\n");
          }
          /** 构建undo log */
          auto before_tuple = ReconstructTuple(&table_info->schema_, delete_tuple, meta, {old_undo_log});
          if (!before_tuple.has_value()) {
            throw Exception("无法撤销之前的修改\n");
          }
          UndoLog undo_log = GetDeleteUndoLog(table_info->schema_, old_undo_log.prev_version_, old_undo_log.ts_, *before_tuple);
          /** 更新txn的undo logs即可，不用修改版本链 */
          txn->ModifyUndoLog(undo_log_idx, undo_log);
        }
        /** 被当前事务insert的tuple，直接更新base tuple即可 */
        meta.is_deleted_ = true;
        table_info->table_->UpdateTupleMeta(meta, modified_rid);
        cnt++;
      }
      continue;
    }
    /** 未来事务对tuple进行了修改 */
    if (meta.ts_ < TXN_START_ID && meta.ts_ > txn->GetReadTs()) {
      txn->SetTainted();
      throw ExecutionException("未来事务对tuple进行了修改");
    }
    /** 构建undo log */
    UndoLog undo_log = GetDeleteUndoLog(table_info->schema_, first_link, meta.ts_, delete_tuple);
    /** 获取tuple lock */
    if (!GetTupleLock(txn_mgr, modified_rid, original_version_link)) {
      txn->SetTainted();
      std::cerr << "获取tuple lock失败\n";
      throw ExecutionException("获取tuple lock失败");
    }
    /** 更新事务的undo log与write set */
    txn->AppendUndoLog(undo_log);
    txn->AppendWriteSet(this->plan_->GetTableOid(), modified_rid);
    /** 更新VersionLink */
    ConstructAndUpdateVersionLink(txn->GetTransactionId(), txn->GetUndoLogNum() - 1, txn_mgr, modified_rid);
    /** 更新base tuple的is_delete标记 */
    meta.ts_ = txn->GetTransactionId();
    meta.is_deleted_ = true;
    table_info->table_->UpdateTupleMeta(meta, modified_rid);
    cnt++;
  }
  std::vector<Value> value_cnt;
  value_cnt.emplace_back(TypeId::INTEGER, cnt);
  *tuple = Tuple{value_cnt, &this->GetOutputSchema()};
  this->is_executed_ = true;
  return true;
}

}  // namespace bustub
