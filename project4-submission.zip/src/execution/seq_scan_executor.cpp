//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// seq_scan_executor.cpp
//
// Identification: src/execution/seq_scan_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/seq_scan_executor.h"
#include "common/config.h"
#include "concurrency/transaction_manager.h"
#include "execution/execution_common.h"
#include "execution/expressions/column_value_expression.h"
#include "execution/expressions/comparison_expression.h"
#include "execution/expressions/constant_value_expression.h"
#include "storage/table/table_heap.h"
#include "storage/table/tuple.h"
#include "type/type_id.h"

namespace bustub {

SeqScanExecutor::SeqScanExecutor(ExecutorContext *exec_ctx, const SeqScanPlanNode *plan)
    : AbstractExecutor(exec_ctx),
      plan_(plan),
      it_(this->GetExecutorContext()->GetCatalog()->GetTable(plan->GetTableOid())->table_->MakeIterator()) {}

void SeqScanExecutor::Init() { this->results_it_ = this->results_.begin(); }

auto SeqScanExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  if (!is_first_) {
    if (this->results_it_ == this->results_.end()) {
      return false;
    }
    *tuple = this->results_it_->first;
    *rid = this->results_it_->second;
    ++this->results_it_;
    return true;
  }
  Transaction *txn = this->GetExecutorContext()->GetTransaction();
  timestamp_t read_ts = txn->GetReadTs();
  while (!this->it_.IsEnd()) {
    TransactionManager *txn_mgr = this->GetExecutorContext()->GetTransactionManager();
    auto [meta, base_tuple] = this->it_.GetTuple();
    std::optional<UndoLink> undo_link = txn_mgr->GetUndoLink(base_tuple.GetRid());
    std::vector<UndoLog> undo_logs;
    bool can_read = false;
    timestamp_t tuple_ts = meta.ts_;
    if ((read_ts >= tuple_ts || tuple_ts == txn->GetTransactionId())) {
      can_read = true;
    }
    while (!can_read && undo_link.has_value() && undo_link->IsValid()) {
      if (txn_mgr->txn_map_.count(undo_link->prev_txn_) == 0) {
        break;
      }
      /** 先保存undo_link指向的undo_log */
      UndoLog undo_log = txn_mgr->GetUndoLog(*undo_link);
      /** 将read ts与tuple ts进行比较 */
      undo_logs.push_back(undo_log);
      /** 直到遇到一个能够读取 */
      if (read_ts >= undo_log.ts_) {
        can_read = true;
        break;
      }
      /** 更新undo_link */
      undo_link = undo_log.prev_version_;
    } /** end of while (undo_link.has_value() && undo_link->IsValid()) */
    if (can_read) {
      std::optional<Tuple> tuple_optional = ReconstructTuple(&this->GetOutputSchema(), base_tuple, meta, undo_logs);
      if (tuple_optional.has_value()) {
        /** filter条件的判断 */
        if (this->plan_->filter_predicate_ != nullptr) {
          Value is_equal = this->plan_->filter_predicate_->Evaluate(&(*tuple_optional), this->plan_->OutputSchema());
          if (!is_equal.IsNull() && !is_equal.GetAs<bool>()) {
            ++this->it_;
            continue;
          }
        }
        *tuple = *tuple_optional;
        *rid = this->it_.GetRID();
        ++this->it_;
        this->results_.emplace_back(*tuple, *rid);
        return true;
      }
    }
    ++this->it_;
  } /** end of while (!this->it_.IsEnd()) */
  this->is_first_ = false;
  return false;
}

}  // namespace bustub
