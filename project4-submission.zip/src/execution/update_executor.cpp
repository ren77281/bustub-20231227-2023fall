//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// update_executor.cpp
//
// Identification: src/execution/update_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//
#include <memory>

#include "catalog/catalog.h"
#include "common/config.h"
#include "common/exception.h"
#include "concurrency/transaction.h"
#include "concurrency/transaction_manager.h"
#include "execution/execution_common.h"
#include "execution/executor_context.h"
#include "execution/executors/update_executor.h"

namespace bustub {

UpdateExecutor::UpdateExecutor(ExecutorContext *exec_ctx, const UpdatePlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

void UpdateExecutor::Init() {
  this->child_executor_->Init();
  RID rid;
  Tuple children_tuple{};
  while (child_executor_->Next(&children_tuple, &rid)) {
    this->rids_.push_back(rid);
  }
}

auto UpdateExecutor::Next([[maybe_unused]] Tuple *tuple, RID *rid) -> bool {
  if (this->is_executed_) {
    return false;
  }
  int32_t cnt = 0;
  Tuple children_tuple{};
  Transaction *txn = this->GetExecutorContext()->GetTransaction();
  TransactionManager *txn_mgr = this->GetExecutorContext()->GetTransactionManager();
  TableInfo *table_info = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->GetTableOid());
  for (const auto &modified_rid : this->rids_) {
    auto [meta, old_tuple] = table_info->table_->GetTuple(modified_rid);
    /** 保存VersionUndoLink */
    std::optional<VersionUndoLink> original_version_link = txn_mgr->GetVersionLink(modified_rid);
    if (!original_version_link.has_value()) {
      txn->SetTainted();
      throw Exception("获取VerionLink失败，存在非法rid\n");
    }
    /** 不能修改其他事务正在操作的tuple */
    if (original_version_link->in_progress_ && meta.ts_ != txn->GetTransactionId()) {
      txn->SetTainted();
      // std::cerr << "不能修改其他事务正在操作的tuple\n";
      throw ExecutionException("不能修改其他事务正在操作的tuple\n");
    }
    UndoLink first_link = original_version_link->prev_;
    /** 如果是自我修改 */
    if (meta.ts_ == txn->GetTransactionId()) {
      if (first_link.IsValid()) {
        /** 先保存该undo log的下标与undo log */
        size_t undo_log_idx = first_link.prev_log_idx_;
        UndoLog old_undo_log = txn->GetUndoLog(undo_log_idx);
        /** 验证第一个undo log由当前事务创建 */
        if (txn->GetTransactionId() != first_link.prev_txn_) {
          txn->SetTainted();
          LOG_ERROR("版本链存在问题，第一个undo log不是当前事务创建，没有解决写写冲突？");
          throw ExecutionException("版本链存在问题，第一个undo log不是当前事务创建，没有解决写写冲突？\n");
        }
        /** 构建undo log */
        Tuple new_tuple{};
        UndoLog undo_log = ConstructUndoLog(old_tuple, table_info, this->plan_->target_expressions_, old_undo_log.ts_,
                                            std::nullopt, old_undo_log, new_tuple);
        /** 更新txn的undo logs即可，不用修改版本链 */
        txn->ModifyUndoLog(undo_log_idx, undo_log);
        /** 只需要更新tuple，无需更新其meta */
        table_info->table_->UpdateTupleInPlace(meta, new_tuple, modified_rid);
      } else {
        /** 只需要更新base tuple */
        table_info->table_->UpdateTupleInPlace(meta,
            GetNewTuple(old_tuple, table_info->schema_, this->plan_->target_expressions_),
            modified_rid);
      }
      cnt++;
      continue;
    }
    /** 未来事务对tuple进行了修改 */
    if (meta.ts_ < TXN_START_ID && meta.ts_ > txn->GetReadTs()) {
      txn->SetTainted();
      // std::cerr << "未来事务对tuple进行了修改\n";
      throw ExecutionException("未来事务对tuple进行了修改");
    }
    /** 获取tuple lock */
    if (!GetTupleLock(txn_mgr, modified_rid, original_version_link)) {
      txn->SetTainted();
      // std::cerr << "获取tuple lock失败\n";
      throw ExecutionException("获取tuple lock失败");
    }
    Tuple new_tuple{};
    /** 由于之前获取的tuple可能被修改过，加了tuple lock需要再获取一次 */
    auto [again_meta, again_tuple] = table_info->table_->GetTuple(modified_rid);
    /** 构建undo log */
    UndoLog undo_log = ConstructUndoLog(again_tuple, table_info, this->plan_->target_expressions_, again_meta.ts_,
                                        first_link, std::nullopt, new_tuple);
    /** 维护txn的write set与undo logs */
    txn->AppendWriteSet(this->plan_->GetTableOid(), modified_rid);
    txn->AppendUndoLog(undo_log);
    /** 更新VersionLink */
    ConstructAndUpdateVersionLink(txn->GetTransactionId(), txn->GetUndoLogNum() - 1, txn_mgr, modified_rid);
    /** 更新base tuple */
    table_info->table_->UpdateTupleInPlace({txn->GetTransactionId(), false}, new_tuple, modified_rid);
    // std::cerr << std::this_thread::get_id() << ' ' << "获取lock成功，rid:" << modified_rid << '\n';
    // std::cerr << std::this_thread::get_id() << ' ' << new_tuple.ToString(&table_info->schema_) << '\n';
    cnt++;
  }
  std::vector<Value> value_cnt;
  value_cnt.emplace_back(TypeId::INTEGER, cnt);
  *tuple = Tuple(value_cnt, &this->GetOutputSchema());
  this->is_executed_ = true;
  return true;
}

}  // namespace bustub
