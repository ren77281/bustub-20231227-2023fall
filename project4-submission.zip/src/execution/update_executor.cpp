//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// update_executor.cpp
//
// Identification: src/execution/update_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//
#include <memory>

#include "catalog/catalog.h"
#include "common/config.h"
#include "concurrency/transaction.h"
#include "concurrency/transaction_manager.h"
#include "execution/execution_common.h"
#include "execution/executors/update_executor.h"

namespace bustub {

UpdateExecutor::UpdateExecutor(ExecutorContext *exec_ctx, const UpdatePlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

void UpdateExecutor::Init() {
  this->child_executor_->Init();
  RID rid;
  Tuple children_tuple{};
  while (child_executor_->Next(&children_tuple, &rid)) {
    this->rids_.push_back(rid);
  }
}

auto UpdateExecutor::Next([[maybe_unused]] Tuple *tuple, RID *rid) -> bool {
  if (this->is_executed_) {
    return false;
  }
  int32_t cnt = 0;
  Tuple children_tuple{};
  Transaction *txn = this->GetExecutorContext()->GetTransaction();
  TransactionManager *txn_mgr = this->GetExecutorContext()->GetTransactionManager();
  TableInfo *table_info = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->GetTableOid());
  for (const auto &rid : this->rids_) {
    auto [meta, old_tuple] = table_info->table_->GetTuple(rid);
    /** 维护tuple的版本链 */
    std::optional<UndoLink> first_link = txn_mgr->GetUndoLink(rid);
    if (!first_link.has_value()) {
      LOG_ERROR("存在非法rid");
      throw ExecutionException("存在非法rid\n");
    }
    cnt++;
    /** 如果是自我修改 */
    if (meta.ts_ == txn->GetTransactionId()) {
      if (first_link->IsValid()) {
        /** 先保存该undo log的下标与undo log */
        size_t undo_log_idx = first_link->prev_log_idx_;
        UndoLog old_undo_log = txn->GetUndoLog(undo_log_idx);
        /** 验证第一个undo log由当前事务创建 */
        if (txn->GetTransactionId() != first_link->prev_txn_) {
          LOG_ERROR("版本链存在问题，第一个undo log不是当前事务创建，没有解决写写冲突？");
          throw ExecutionException("版本链存在问题，第一个undo log不是当前事务创建，没有解决写写冲突？\n");
        }
        /** 构建undo log */
        Tuple new_tuple{};
        UndoLog undo_log = ConstructUndoLog(old_tuple, table_info, this->plan_->target_expressions_, old_undo_log.ts_,
                                            std::nullopt, old_undo_log, new_tuple);
        /** 更新txn的undo logs即可，不用修改版本链 */
        txn->ModifyUndoLog(undo_log_idx, undo_log);
        /** 只需要更新tuple，无需更新其meta */
        table_info->table_->UpdateTupleInPlace(meta, new_tuple, rid);
      } else {
        /** 只需要更新base tuple */
        table_info->table_->UpdateTupleInPlace(
            meta, GetNewTuple(old_tuple, table_info->schema_, this->plan_->target_expressions_), rid);
      }
      continue;
    }
    /** 检测写写冲突 */
    if (meta.ts_ >= TXN_START_ID || (meta.ts_ < TXN_START_ID && meta.ts_ > txn->GetReadTs())) {
      LOG_DEBUG("发生了写写冲突");
      txn->SetTainted();
      throw ExecutionException("发生了写写冲突");
    }
    /** 正常写入 */
    Tuple new_tuple{};
    /** 构建undo log */
    UndoLog undo_log = ConstructUndoLog(old_tuple, table_info, this->plan_->target_expressions_, meta.ts_, first_link,
                                        std::nullopt, new_tuple);
    /** 构建指向undo log的undo link并维护版本链 */
    ConstructAndUpdateUndoLink(txn->GetTransactionId(), txn->GetUndoLogNum(), txn_mgr, rid);
    /** 更新base tuple */
    table_info->table_->UpdateTupleInPlace({txn->GetTransactionId(), false}, new_tuple, rid);
    /** 维护txn的write set与undo logs */
    txn->AppendWriteSet(this->plan_->GetTableOid(), rid);
    txn->AppendUndoLog(undo_log);
  }
  std::vector<Value> value_cnt;
  value_cnt.emplace_back(TypeId::INTEGER, cnt);
  *tuple = Tuple(value_cnt, &this->GetOutputSchema());
  this->is_executed_ = true;
  return true;
}

}  // namespace bustub
