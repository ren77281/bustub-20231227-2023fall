#include "execution/execution_common.h"
#include <optional>
#include <sstream>
#include "catalog/catalog.h"
#include "catalog/schema.h"
#include "common/config.h"
#include "common/macros.h"
#include "concurrency/transaction.h"
#include "concurrency/transaction_manager.h"
#include "execution/expressions/abstract_expression.h"
#include "fmt/core.h"
#include "storage/table/table_heap.h"
#include "storage/table/table_iterator.h"
#include "storage/table/tuple.h"
#include "type/value.h"
#include "type/value_factory.h"

namespace bustub {

auto ReconstructTuple(const Schema *schema, const Tuple &base_tuple, const TupleMeta &base_meta,
                      const std::vector<UndoLog> &undo_logs) -> std::optional<Tuple> {
  /** 先将原值填入values数组，后续将根据undo log修改values数组 */
  std::vector<Value> values;
  values.resize(schema->GetColumnCount());
  for (size_t idx = 0; idx < values.size(); idx++) {
    values[idx] = base_tuple.GetValue(schema, idx);
  }
  /** 遍历所有的undo log */
  for (const auto &undo_log : undo_logs) {
    /** 如果回滚了，直接往后遍历 */
    if (undo_log.is_deleted_) {
      continue;
    }
    std::vector<Column> modified_cols;
    std::vector<size_t> modified_col_idxs;
    /** 这里的idx指的是base_tuple的列下标 */
    for (size_t idx = 0; idx < undo_log.modified_fields_.size(); idx++) {
      if (undo_log.modified_fields_[idx]) {
        modified_cols.push_back(schema->GetColumn(idx));
        modified_col_idxs.push_back(idx);
      }
    }
    Schema modified_schema{modified_cols};
    /** 这里的idx指的是undo log中tuple的列下标 */
    for (size_t idx = 0; idx < modified_cols.size(); idx++) {
      /** 对values数组应用修改 */
      values[modified_col_idxs[idx]] = Value{undo_log.tuple_.GetValue(&modified_schema, idx)};
    }
  }
  if ((undo_logs.empty() && !base_meta.is_deleted_) || (!undo_logs.empty() && !undo_logs.back().is_deleted_)) {
    return std::make_optional(Tuple{values, schema});
  }
  return std::nullopt;
}

void TxnMgrDbg(const std::string &info, TransactionManager *txn_mgr, const TableInfo *table_info,
               TableHeap *table_heap) {
  fmt::println(stderr, "debug_hook: {}", info);

  TableIterator it(table_heap->MakeIterator());
  while (!it.IsEnd()) {
    auto [meta, base_tuple] = it.GetTuple();
    RID rid = base_tuple.GetRid();
    std::optional<UndoLink> undo_link = txn_mgr->GetUndoLink(rid);
    std::stringstream row_ss;
    row_ss << "RID=" << rid.GetPageId() << '/' << rid.GetSlotNum() << " ts=";
    if (meta.ts_ > TXN_START_ID) {
      row_ss << "txn" << (meta.ts_ ^ TXN_START_ID) << ' ';
    } else {
      row_ss << meta.ts_ << ' ';
    }
    if (meta.is_deleted_) {
      row_ss << "<del marker> ";
    }
    row_ss << "tuple=" << base_tuple.ToString(&table_info->schema_);
    fmt::println(stderr, row_ss.str().c_str());
    std::vector<UndoLog> undo_logs;
    while (undo_link.has_value() && undo_link->IsValid()) {
      auto undo_log = txn_mgr->GetUndoLogOptional(*undo_link);
      if (!undo_log.has_value()) {
        break;
      }
      std::stringstream tuple_ss;
      tuple_ss << "  txn" << (undo_link->prev_txn_ ^ TXN_START_ID) << ' ';
      undo_logs.push_back(*undo_log);
      auto tuple = ReconstructTuple(&table_info->schema_, base_tuple, meta, undo_logs);
      if (tuple.has_value()) {
        tuple_ss << tuple->ToString(&table_info->schema_) << ' ';
      } else {
        tuple_ss << " <del> ";
      }
      tuple_ss << "ts=" << undo_log->ts_;
      fmt::println(stderr, tuple_ss.str().c_str());
      undo_link = undo_log->prev_version_;
    }
    ++it;
  }
  // debug_hook: before verify scan
  // RID=0/0 ts=txn8 tuple=(1, <NULL>, <NULL>)
  //   txn8@0 (2, _, _) ts=1
  // RID=0/1 ts=3 tuple=(3, <NULL>, <NULL>)
  //   txn5@0 <del> ts=2
  //   txn3@0 (4, <NULL>, <NULL>) ts=1
  // RID=0/2 ts=4 <del marker> tuple=(<NULL>, <NULL>, <NULL>)
  //   txn7@0 (5, <NULL>, <NULL>) ts=3
  // RID=0/3 ts=txn6 <del marker> tuple=(<NULL>, <NULL>, <NULL>)
  //   txn6@0 (6, <NULL>, <NULL>) ts=2
  //   txn3@1 (7, _, _) ts=1
}

auto ConstructUndoLog(const Tuple &old_tuple, TableInfo *table_info,
                      const std::vector<AbstractExpressionRef> &expressions, timestamp_t ts,
                      std::optional<UndoLink> link, std::optional<UndoLog> old_undo_log, Tuple &new_tuple) -> UndoLog {
  std::vector<Column> old_undo_log_cols;
  if (old_undo_log.has_value()) {
    for (size_t i = 0; i < old_undo_log->modified_fields_.size(); i++) {
      if (old_undo_log->modified_fields_[i]) {
        old_undo_log_cols.push_back(table_info->schema_.GetColumn(i));
      }
    }
  }
  Schema old_undo_log_schema{old_undo_log_cols};
  UndoLog new_undo_log;
  new_undo_log.is_deleted_ = old_undo_log.has_value() ? old_undo_log->is_deleted_ : false;
  new_undo_log.modified_fields_.resize(table_info->schema_.GetColumnCount(), false);
  new_undo_log.ts_ = ts;
  std::vector<Value> new_undo_log_vals;
  std::vector<Value> new_tuple_vals;
  new_tuple_vals.reserve(expressions.size());
  std::vector<Column> new_undo_log_cols;
  size_t old_modified_idx = 0;
  for (size_t i = 0; i < expressions.size(); i++) {
    std::optional<Value> undo_log_val;
    std::optional<Column> undo_log_col;
    const auto &expr = expressions[i];
    Value new_val = expr->Evaluate(&old_tuple, table_info->schema_);
    Value old_val = old_tuple.GetValue(&table_info->schema_, i);
    new_tuple_vals.push_back(new_val);
    if (!new_val.CompareExactlyEquals(old_val)) {
      undo_log_val = old_val;
      undo_log_col = table_info->schema_.GetColumn(i);
    }
    if (old_undo_log.has_value() && old_undo_log->modified_fields_[i]) {
      undo_log_val = old_undo_log->tuple_.GetValue(&old_undo_log_schema, old_modified_idx);
      undo_log_col = old_undo_log_schema.GetColumn(old_modified_idx++);
    }
    if (undo_log_val.has_value()) {
      new_undo_log_vals.push_back(*undo_log_val);
      new_undo_log_cols.push_back(*undo_log_col);
      new_undo_log.modified_fields_[i] = true;
    }
  }
  /** 构建undo log的增量 */
  Schema new_undo_log_schema{new_undo_log_cols};
  new_undo_log.tuple_ = Tuple{new_undo_log_vals, &new_undo_log_schema};
  new_undo_log.prev_version_ = link.has_value() ? *link : old_undo_log->prev_version_;
  /** 输出new_tuple */
  new_tuple = Tuple{new_tuple_vals, &table_info->schema_};
  return new_undo_log;
}

auto GetNewTuple(const Tuple &old_tuple, const Schema &schema, const std::vector<AbstractExpressionRef> &expressions)
    -> Tuple {
  std::vector<Value> values;
  values.reserve(expressions.size());
  for (const auto &expr : expressions) {
    values.push_back(expr->Evaluate(&old_tuple, schema));
  }
  return Tuple{values, &schema};
}

void ConstructAndUpdateVersionLink(txn_id_t txn_id, size_t undo_log_idx, TransactionManager *txn_mgr, RID rid) {
  UndoLink undo_link;
  undo_link.prev_txn_ = txn_id;
  undo_link.prev_log_idx_ = undo_log_idx;
  txn_mgr->UpdateVersionLink(rid, VersionUndoLink{undo_link, true}, nullptr);
}

auto GetDeleteUndoLog(const Schema &schema, const UndoLink &link, timestamp_t ts, const Tuple &tuple) -> UndoLog {
  UndoLog undo_log;
  undo_log.is_deleted_ = false;
  undo_log.modified_fields_.resize(schema.GetColumnCount(), true);
  undo_log.prev_version_ = link;
  undo_log.ts_ = ts;
  undo_log.tuple_ = tuple;
  return undo_log;
}

auto FindFirstUndoLog(const RID &rid, const TableInfo *table_info, TransactionManager *txn_mgr, Transaction *txn,
                      std::optional<AbstractExpressionRef> filter) -> std::optional<Tuple> {
  auto [meta, base_tuple] = table_info->table_->GetTuple(rid);
  std::optional<UndoLink> undo_link = txn_mgr->GetUndoLink(rid);
  std::vector<UndoLog> undo_logs;
  bool can_read = false;
  timestamp_t tuple_ts = meta.ts_;
  timestamp_t read_ts = txn->GetReadTs();
  if ((read_ts >= tuple_ts || tuple_ts == txn->GetTransactionId())) {
    can_read = true;
  }
  while (!can_read && undo_link.has_value() && undo_link->IsValid()) {
    /** 先保存undo_link指向的undo_log */
    auto undo_log = txn_mgr->GetUndoLogOptional(*undo_link);
    /** 由于GC的存在，可能有悬空指针 */
    if (!undo_log.has_value()) {
      break;
    }
    undo_logs.push_back(*undo_log);
    /** 将read ts与tuple ts进行比较，直到遇到一个能够读取 */
    if (read_ts >= undo_log->ts_) {
      can_read = true;
      break;
    }
    /** 更新undo_link */
    undo_link = undo_log->prev_version_;
  } /** end of while (undo_link.has_value() && undo_link->IsValid()) */
  if (can_read) {
    std::optional<Tuple> tuple_optional = ReconstructTuple(&table_info->schema_, base_tuple, meta, undo_logs);
    if (tuple_optional.has_value()) {
      /** filter条件的判断 */
      if (filter.has_value() && *filter != nullptr) {
        Value is_equal = (*filter)->Evaluate(&(*tuple_optional), table_info->schema_);
        if (!is_equal.IsNull() && !is_equal.GetAs<bool>()) {
          return std::nullopt;
        }
      }
      return tuple_optional;
    }
  }
  return std::nullopt;
}

auto IsTupleDelete(const TableInfo *table_info, TransactionManager *txn_mgr, const RID &rid) -> bool {
  TupleMeta meta = table_info->table_->GetTupleMeta(rid);
  if (!meta.is_deleted_) {
    return false;
  }
  std::optional<UndoLink> undo_link = txn_mgr->GetUndoLink(rid);
  while (undo_link.has_value() && undo_link->IsValid()) {
    auto undo_log = txn_mgr->GetUndoLogOptional(*undo_link);
    if (!undo_log.has_value()) {
      break;
    }
    if (!undo_log->is_deleted_) {
      return false;
    }
    undo_link = undo_log->prev_version_;
  }
  return true;
}

auto GetTupleLock(TransactionManager *txn_mgr, RID rid, std::optional<VersionUndoLink> original_version_link) -> bool {
  if (!original_version_link.has_value()) {
    return txn_mgr->UpdateVersionLink(rid, VersionUndoLink{UndoLink{}, true},
                                      [](std::optional<VersionUndoLink> cur_version_link) -> bool { return !cur_version_link.has_value(); });
  }
  return txn_mgr->UpdateVersionLink(rid, VersionUndoLink{original_version_link->prev_, true},
                                    [original_version_link](std::optional<VersionUndoLink> cur_version_link) -> bool {
                                      if (original_version_link.has_value() && cur_version_link.has_value()) {
                                        return *original_version_link == *cur_version_link;
                                      }
                                      return (!original_version_link.has_value() && !cur_version_link.has_value());
                                    });
}

}  // namespace bustub
