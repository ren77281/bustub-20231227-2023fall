//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// insert_executor.cpp
//
// Identification: src/execution/insert_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <ctime>
#include <memory>
#include <thread>

#include "common/config.h"
#include "common/exception.h"
#include "concurrency/transaction.h"
#include "concurrency/transaction_manager.h"
#include "execution/executor_context.h"
#include "execution/executors/insert_executor.h"
#include "execution/execution_common.h"

namespace bustub {

InsertExecutor::InsertExecutor(ExecutorContext *exec_ctx, const InsertPlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {}

void InsertExecutor::Init() { this->child_executor_->Init(); }

auto InsertExecutor::Next([[maybe_unused]] Tuple *tuple, RID *rid) -> bool {
  if (this->is_executed_) {
    return false;
  }
  int32_t cnt = 0;
  Tuple children_tuple{};
  Transaction *txn = this->GetExecutorContext()->GetTransaction();
  TransactionManager *txn_mgr = this->GetExecutorContext()->GetTransactionManager();
  while (this->child_executor_->Next(&children_tuple, rid)) {
    TableInfo *table_info = this->GetExecutorContext()->GetCatalog()->GetTable(this->plan_->GetTableOid());
    std::vector<IndexInfo *> indexes = this->GetExecutorContext()->GetCatalog()->GetTableIndexes(table_info->name_);
    /** 检查主键的唯一性冲突 */
    std::vector<RID> rids;
    for (const auto &index_info : indexes) {
      if (!index_info->is_primary_key_) {
        continue;
      }
      Tuple insert_key =
          children_tuple.KeyFromTuple(table_info->schema_, index_info->key_schema_, index_info->index_->GetKeyAttrs());
      index_info->index_->ScanKey(insert_key, &rids, txn);
    }
    /** 存在唯一性冲突 */
    if (!rids.empty()) {
      RID modified_rid = rids[0];
      TupleMeta meta = table_info->table_->GetTupleMeta(modified_rid);
      std::optional<VersionUndoLink> original_version_link = txn_mgr->GetVersionLink(modified_rid);
      /** 不能修改其他事务正在操作的tuple */
      if (original_version_link->in_progress_ && meta.ts_ != txn->GetTransactionId()) {
        txn->SetTainted();
        // std::cerr << "不能修改其他事务正在操作的tuple\n";
        throw ExecutionException("不能修改其他事务正在操作的tuple\n");
      }
      /** 自我修改 */
      if (meta.ts_ == txn->GetTransactionId()) {
        if (!original_version_link->in_progress_) {
          // std::cerr << "!!!!!!!!!!!\n";
          throw Exception("!!!!!!!!!!!!\n");
        }
        /** 只有tuple被删除时，才能自我修改 */
        if (!meta.is_deleted_) {
          txn->SetTainted();
          // std::cerr << "唯一键冲突（正在操作的事务是自己，但是tuple未删除）\n";
          throw ExecutionException("唯一键冲突（自我修改时，但是tuple未删除）");
        }
        /** 自我修改只需要update table heap */
        table_info->table_->UpdateTupleInPlace({txn->GetTransactionId(), false}, children_tuple, modified_rid);
        cnt++;
      } else {  /** 没有事务正在操作 */
        /** 获取tuple lock */
        if (!GetTupleLock(txn_mgr, modified_rid, original_version_link)) {
          txn->SetTainted();
          // std::cerr << "唯一键冲突（check失败）\n";
          throw ExecutionException("唯一键冲突（check失败）");
        }
        /** tuple被删除，且不是未来的删除 */
        if (!(meta.is_deleted_ && txn->GetReadTs() >= meta.ts_)) {
          txn->SetTainted();
          // std::cerr << "唯一键冲突（tuple没有被删除、被未来删除）\n";
          throw ExecutionException("唯一键冲突（tuple没有被删除、被未来删除）");
        }
        /** 保存VersionLink */
        auto undo_link = txn_mgr->GetUndoLink(modified_rid);
        if (!undo_link.has_value()) {
          throw Exception("无法获取undo link");
        }
        /** 构建undo log */
        UndoLog undo_log;
        undo_log.is_deleted_ = true;
        undo_log.ts_ = meta.ts_;
        undo_log.modified_fields_.resize(table_info->schema_.GetColumnCount(), false);
        undo_log.prev_version_ = original_version_link->prev_;
        undo_log.tuple_ = table_info->table_->GetTuple(modified_rid).second;
        /** 维护txn的write set和undo logs */
        txn->AppendWriteSet(table_info->oid_, modified_rid);
        txn->AppendUndoLog(undo_log);
        /** 更新VersionLink */
        ConstructAndUpdateVersionLink(txn->GetTransactionId(), txn->GetUndoLogNum() - 1, txn_mgr, modified_rid);
        /** 只需要update table heap */
        table_info->table_->UpdateTupleInPlace({txn->GetTransactionId(), false}, children_tuple, modified_rid);
        cnt++;
      }
    } else {  /** 不存在冲突，进行正常的insert逻辑 */
      /** 将tuple插入table hea */
      auto new_rid = table_info->table_->InsertTuple(TupleMeta{txn->GetTransactionId(), false}, children_tuple);
      if (!new_rid.has_value()) {
        txn->SetTainted();
        throw ExecutionException("Insert返回的rid无效");
      }
      /** 维护VersionLink，获取tuple lock */
      if (!GetTupleLock(txn_mgr, *new_rid, std::nullopt)) {
        txn->SetTainted();
        throw ExecutionException("唯一键冲突（不存在冲突时check失败）");
      }
      /** 维护事务的write set */
      txn->AppendWriteSet(this->plan_->GetTableOid(), *new_rid);
      /** 维护索引 */
      std::vector<IndexInfo *> indexes = this->GetExecutorContext()->GetCatalog()->GetTableIndexes(table_info->name_);
      for (const IndexInfo *index_info : indexes) {
        Tuple key_tuple = children_tuple.KeyFromTuple(table_info->schema_, index_info->key_schema_,
                                                      index_info->index_->GetKeyAttrs());
        if (!index_info->index_->InsertEntry(key_tuple, *new_rid, txn)) {
          txn_mgr->UpdateVersionLink(*new_rid, VersionUndoLink{UndoLink{}, false});
          txn->SetTainted();
          // std::cerr << "唯一键冲突（插入索引时失败）\n";
          throw ExecutionException("唯一键冲突（插入索引时失败）");
        }
      }
      cnt++;
    }
  }  // end of while (this->child_executor_->Next(&children_tuple, rid))
  std::vector<Value> value_cnt;
  value_cnt.emplace_back(TypeId::INTEGER, cnt);
  *tuple = Tuple(value_cnt, &this->GetOutputSchema());
  this->is_executed_ = true;
  return true;
}

}  // namespace bustub
