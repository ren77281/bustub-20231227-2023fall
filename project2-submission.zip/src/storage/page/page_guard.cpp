#include "storage/page/page_guard.h"
#include <utility>
#include "buffer/buffer_pool_manager.h"

namespace bustub {

/** 进行资源转移即可 */
BasicPageGuard::BasicPageGuard(BasicPageGuard &&that) noexcept {
  // std::cout << "BasicPageGuard::move construct\n";
  std::swap(this->page_, that.page_);
  std::swap(this->bpm_, that.bpm_);
  std::swap(this->is_dirty_, that.is_dirty_);
}

/** 手动放弃protect对象的所有权 */
void BasicPageGuard::Drop() {
  // std::cout << "BasicPageGuard::Drop\n";
  if (this->page_ != nullptr) {
    this->bpm_->UnpinPage(this->PageId(), this->is_dirty_);
    this->page_ = nullptr;
    this->bpm_ = nullptr;
    this->is_dirty_ = false;
  }
}

/** 与移动构造不同，移动赋值需要先放弃当前protect对象的所有权，再进行资源转移 */
auto BasicPageGuard::operator=(BasicPageGuard &&that) noexcept -> BasicPageGuard & {
  if (this->page_ != that.page_) {
    // std::cout << "BasicPageGuard::operator=\n";
    this->Drop();
    std::swap(this->page_, that.page_);
    std::swap(this->bpm_, that.bpm_);
    std::swap(this->is_dirty_, that.is_dirty_);
  }
  return *this;
}

BasicPageGuard::~BasicPageGuard() { this->Drop(); }

auto BasicPageGuard::UpgradeRead() -> ReadPageGuard {
  // std::cout << "BasicPageGuard::UpgradeRead\n";
  if (this->page_ != nullptr) {
    this->page_->RLatch();
  }
  ReadPageGuard rpg(this->bpm_, this->page_);
  this->page_ = nullptr;
  this->bpm_ = nullptr;
  return rpg;
}

auto BasicPageGuard::UpgradeWrite() -> WritePageGuard {
  // std::cout << "BasicPageGuard::UpgradeWrite\n";
  if (this->page_ != nullptr) {
    this->page_->WLatch();
  }
  WritePageGuard wpg(this->bpm_, this->page_);
  this->page_ = nullptr;
  this->bpm_ = nullptr;
  return wpg;
}

ReadPageGuard::ReadPageGuard(ReadPageGuard &&that) noexcept { this->guard_ = std::move(that.guard_); }

auto ReadPageGuard::operator=(ReadPageGuard &&that) noexcept -> ReadPageGuard & {
  // std::cout << "ReadPageGuard::operator=\n";
  if (this->guard_.page_ != that.guard_.page_) {
    this->Drop();
    this->guard_ = std::move(that.guard_);
  }
  return *this;
}

void ReadPageGuard::Drop() {
  // std::cout << "ReadPageGuard::Drop\n";
  if (this->guard_.page_ != nullptr) {
    this->guard_.page_->RUnlatch();
    this->guard_.Drop();
  }
}

ReadPageGuard::~ReadPageGuard() { this->Drop(); }

WritePageGuard::WritePageGuard(WritePageGuard &&that) noexcept { this->guard_ = std::move(that.guard_); }

auto WritePageGuard::operator=(WritePageGuard &&that) noexcept -> WritePageGuard & {
  // std::cout << "WritePageGuard::operator=\n";
  if (this->guard_.page_ != that.guard_.page_) {
    this->Drop();
    this->guard_ = std::move(that.guard_);
  }
  return *this;
}

void WritePageGuard::Drop() {
  // std::cout << "WritePageGuard::Drop\n";
  if (this->guard_.page_ != nullptr) {
    this->guard_.page_->WUnlatch();
    /** 因为获取的Page类型是Write，所以设置脏位 */
    this->guard_.is_dirty_ = true;
    this->guard_.Drop();
  }
}

WritePageGuard::~WritePageGuard() { this->Drop(); }

}  // namespace bustub
